injectEmptyTemplate();
var searchResults = searchForEBooks();
bindSearchResultsToTemplate(searchResults);